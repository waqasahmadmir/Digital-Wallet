package prc;

import java.awt.*;

public class Runner {
    public static void main(String[] args) {
        Frame1 f=new Frame1();


    }
}

